import { GoogleGenAI } from "@google/genai";
import { Hero, Artifact, ArtifactSet, ArtifactSlot, Stat, StatName, Rarity } from './types';
import { ARTIFACT_SETS, ARTIFACT_MAIN_STATS } from './data';

// --- GEMINI API & AI LOGIC ---
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    console.error("API_KEY is not set in environment variables. AI will use fallback logic.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY! });

export async function getAiAction(attacker: Hero, playerTeam: Hero[], enemyTeam: Hero[]): Promise<{ action: 'attack', target: string } | null> {
    if (!API_KEY) { // Fallback logic
        const validTargets = playerTeam.filter(h => h.hp > 0);
        if (validTargets.length === 0) return null;
        // Simple logic: attack lowest HP target
        const lowestHpTarget = validTargets.reduce((prev, curr) => prev.hp < curr.hp ? prev : curr);
        return { action: 'attack', target: lowestHpTarget.uuid };
    }

    const prompt = `You are a strategic AI for a fantasy RPG. Your goal is to defeat the player's team.
    Current Battle State:
    - Player Team: ${JSON.stringify(playerTeam.filter(h => h.hp > 0).map(h => ({ uuid: h.uuid, name: h.name, hp: h.hp, role: h.role, level: h.level })))}
    - Your Team (Enemies): ${JSON.stringify(enemyTeam.filter(e => e.hp > 0).map(e => ({ uuid: e.uuid, name: e.name, hp: e.hp, role: e.role, level: e.level })))}
    It is currently the turn of: ${JSON.stringify({ uuid: attacker.uuid, name: attacker.name, role: attacker.role, level: attacker.level })}.
    Your task is to choose the best target to attack from the Player Team.
    Prioritize: 1. Low-health heroes. 2. 'Attacker' or 'Support' roles. 3. Avoid 'Defender' roles unless necessary.
    You MUST respond with a JSON object in the following format and nothing else:
    {"action": "attack", "target": "hero_uuid_to_attack"}`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } },
        });
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }
        
        const parsedData = JSON.parse(jsonStr);
        // Validate that the chosen target is alive and valid
        if (playerTeam.find(h => h.uuid === parsedData.target && h.hp > 0)) {
            return parsedData;
        }
        throw new Error("AI returned an invalid or defeated target.");
    } catch (e) {
        console.error("AI Action Error:", e);
        // Fallback to simple logic on API error
        const validTargets = playerTeam.filter(h => h.hp > 0);
        if (validTargets.length === 0) return null;
        const lowestHpTarget = validTargets.reduce((prev, curr) => prev.hp < curr.hp ? prev : curr);
        return { action: 'attack', target: lowestHpTarget.uuid };
    }
}

// --- HERO & ARTIFACT UTILS ---
let idCounter = 0;
export const createHeroInstance = (heroTemplate: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'>, isEnemy = false): Hero => {
    idCounter++;
    return {
        ...heroTemplate,
        id: idCounter,
        uuid: `${isEnemy ? 'enemy' : 'player'}-${idCounter}-${Date.now()}-${Math.random()}`,
        hp: heroTemplate.maxHp,
        equippedArtifacts: { Weapon: null, Helmet: null, Armor: null, Boots: null, },
    };
};

export const createArtifactInstance = (rarity: Rarity, level: number = 1, slot: ArtifactSlot): Artifact => {
    idCounter++;
    const possibleMainStats = ARTIFACT_MAIN_STATS[slot];
    const mainStatInfo = possibleMainStats[Math.floor(Math.random() * possibleMainStats.length)];
    
    // Simplified value generation
    const baseValue = (rarity === 'Common' ? 10 : 20) * (mainStatInfo.isPercent ? 1 : 10);

    const newArtifact: Artifact = {
        uuid: `art-${idCounter}-${Date.now()}`,
        set: (Object.keys(ARTIFACT_SETS) as ArtifactSet[])[Math.floor(Math.random() * Object.keys(ARTIFACT_SETS).length)],
        slot: slot,
        rarity: rarity,
        level: level,
        mainStat: { stat: mainStatInfo.stat, value: baseValue, isPercent: mainStatInfo.isPercent },
        subStats: [], // Sub-stats can be added on upgrade
    };
    return newArtifact;
};

export const calculateFinalHeroStats = (baseHero: Hero, allArtifacts: Artifact[]): Hero => {
    const finalHero = JSON.parse(JSON.stringify(baseHero)); // Deep copy to avoid mutation

    if (!baseHero.equippedArtifacts) return finalHero;

    const equippedUuids = Object.values(baseHero.equippedArtifacts).filter(Boolean) as string[];
    if (equippedUuids.length === 0) return finalHero;

    const equippedArtifacts = allArtifacts.filter(a => equippedUuids.includes(a.uuid));

    const flatBonuses: Record<StatName, number> = { maxHp: 0, attack: 0, defense: 0, speed: 0 };
    const percentBonuses: Record<StatName, number> = { maxHp: 0, attack: 0, defense: 0, speed: 0 };
    const setCounts: Partial<Record<ArtifactSet, number>> = {};

    // 1. Gather stats from artifacts
    for (const artifact of equippedArtifacts) {
        const stats = [artifact.mainStat, ...artifact.subStats];
        for (const stat of stats) {
            if (stat.isPercent) {
                percentBonuses[stat.stat] = (percentBonuses[stat.stat] || 0) + stat.value;
            } else {
                flatBonuses[stat.stat] = (flatBonuses[stat.stat] || 0) + stat.value;
            }
        }
        setCounts[artifact.set] = (setCounts[artifact.set] || 0) + 1;
    }

    // 2. Apply set bonuses to percent bonuses
    for (const setName in setCounts) {
        const setDef = ARTIFACT_SETS[setName as ArtifactSet];
        const setCount = setCounts[setName as ArtifactSet]!;
        if (setCount >= setDef.pieces) {
            const numSets = Math.floor(setCount / setDef.pieces);
            percentBonuses[setDef.stat] = (percentBonuses[setDef.stat] || 0) + (setDef.value * numSets);
        }
    }
    
    // 3. Apply bonuses
    const heroWithFlatBonuses = {
        maxHp: baseHero.maxHp + flatBonuses.maxHp,
        attack: baseHero.attack + flatBonuses.attack,
        defense: baseHero.defense + flatBonuses.defense,
        speed: baseHero.speed + flatBonuses.speed,
    };

    finalHero.maxHp = Math.round(heroWithFlatBonuses.maxHp * (1 + percentBonuses.maxHp / 100));
    finalHero.attack = Math.round(heroWithFlatBonuses.attack * (1 + percentBonuses.attack / 100));
    finalHero.defense = Math.round(heroWithFlatBonuses.defense * (1 + percentBonuses.defense / 100));
    finalHero.speed = Math.round(heroWithFlatBonuses.speed * (1 + percentBonuses.speed / 100));
    
    finalHero.hp = Math.min(finalHero.hp, finalHero.maxHp);

    return finalHero;
};