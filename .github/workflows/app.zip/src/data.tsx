import { Rarity, Hero, ArtifactSet, Stage, Dungeon, StatName } from './types';

export const RARITY_STYLES: Record<Rarity, { color: string; shadow: string }> = {
    Common: { color: '#9e9e9e', shadow: '0 0 5px #9e9e9e' },
    Rare: { color: '#4fc3f7', shadow: '0 0 8px #4fc3f7' },
    Epic: { color: '#ab47bc', shadow: '0 0 10px #ab47bc' },
    Legendary: { color: '#ffca28', shadow: '0 0 12px #ffca28' },
};

export const SUMMON_CHANCES = {
    Common: 0.70,
    Rare: 0.25,
    Epic: 0.045,
    Legendary: 0.005,
};

export const LEVEL_UP_COST_BASE = 100;
export const LEVEL_UP_COST_MULTIPLIER = 50;
export const LEVEL_UP_STAT_INCREASE_PERCENT = 1.08;
export const getLevelUpCost = (level: number) => LEVEL_UP_COST_BASE + (level * LEVEL_UP_COST_MULTIPLIER);

export const HERO_POOL: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'>[] = [
    // Common
    { name: 'Squire', rarity: 'Common', role: 'Defender', level: 1, maxHp: 120, attack: 10, defense: 15, speed: 10, imageUrl: '🛡️' },
    { name: 'Acolyte', rarity: 'Common', role: 'Support', level: 1, maxHp: 90, attack: 12, defense: 8, speed: 12, imageUrl: '✙' },
    { name: 'Militia Spearman', rarity: 'Common', role: 'Attacker', level: 1, maxHp: 100, attack: 15, defense: 10, speed: 11, imageUrl: '🔱' },
    { name: 'Scout', rarity: 'Common', role: 'Specialist', level: 1, maxHp: 85, attack: 13, defense: 7, speed: 15, imageUrl: '🏹' },

    // Rare
    { name: 'Knight', rarity: 'Rare', role: 'Defender', level: 1, maxHp: 180, attack: 20, defense: 25, speed: 12, imageUrl: '🐴' },
    { name: 'Priest', rarity: 'Rare', role: 'Support', level: 1, maxHp: 130, attack: 22, defense: 15, speed: 14, imageUrl: '🕊️' },
    { name: 'Gladiator', rarity: 'Rare', role: 'Attacker', level: 1, maxHp: 150, attack: 30, defense: 18, speed: 13, imageUrl: '⚔️' },

    // Epic
    { name: 'Paladin', rarity: 'Epic', role: 'Defender', level: 1, maxHp: 250, attack: 35, defense: 40, speed: 15, imageUrl: '🏰' },
    { name: 'Archmage', rarity: 'Epic', role: 'Specialist', level: 1, maxHp: 180, attack: 50, defense: 25, speed: 18, imageUrl: '🧙' },
    { name: 'Assassin', rarity: 'Epic', role: 'Attacker', level: 1, maxHp: 160, attack: 55, defense: 20, speed: 25, imageUrl: '🔪' },

    // Legendary
    { name: 'Dragon Knight', rarity: 'Legendary', role: 'Attacker', level: 1, maxHp: 300, attack: 70, defense: 50, speed: 22, imageUrl: '🐲' },
    { name: 'Celestial Guardian', rarity: 'Legendary', role: 'Support', level: 1, maxHp: 250, attack: 40, defense: 60, speed: 20, imageUrl: '😇' },
];

export const ENEMY_POOL: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'>[] = [
    { name: 'Goblin Scout', rarity: 'Common', role: 'Attacker', level: 1, maxHp: 80, attack: 12, defense: 5, speed: 15, imageUrl: '👺' },
    { name: 'Orc Grunt', rarity: 'Common', role: 'Defender', level: 1, maxHp: 150, attack: 15, defense: 12, speed: 8, imageUrl: '👹' },
    { name: 'Shadow Wisp', rarity: 'Rare', role: 'Specialist', level: 3, maxHp: 100, attack: 20, defense: 10, speed: 20, imageUrl: '👻' },
    { name: 'Ogre Brute', rarity: 'Rare', role: 'Defender', level: 5, maxHp: 300, attack: 25, defense: 20, speed: 7, imageUrl: '🗿' },
    { name: 'Dark Sorcerer', rarity: 'Epic', role: 'Specialist', level: 8, maxHp: 200, attack: 45, defense: 25, speed: 17, imageUrl: '😈' },
    { name: 'Young Dragon', rarity: 'Epic', role: 'Attacker', level: 10, maxHp: 1000, attack: 60, defense: 40, speed: 25, imageUrl: '🐉' },
];

export const STAGES: Stage[] = [
    { id: 1, name: "Whispering Woods", enemies: [ENEMY_POOL[0], ENEMY_POOL[0]], rewards: { gold: 50, crystals: 1 } },
    { id: 2, name: "Orc Camp", enemies: [ENEMY_POOL[0], ENEMY_POOL[1]], rewards: { gold: 100, crystals: 1 } },
    { id: 3, name: "Haunted Ruins", enemies: [ENEMY_POOL[1], ENEMY_POOL[2], ENEMY_POOL[1]], rewards: { gold: 200, crystals: 2 } },
    { id: 4, name: "Ogre's Pass", enemies: [ENEMY_POOL[3], ENEMY_POOL[1]], rewards: { gold: 350, crystals: 3 } },
    { id: 5, name: "Sorcerer's Tower", enemies: [ENEMY_POOL[2], ENEMY_POOL[4], ENEMY_POOL[2]], rewards: { gold: 500, crystals: 5 } },
];

export const DUNGEONS: Dungeon[] = [
    { id: 1, name: "Dragon's Lair - Stage 1", enemies: [ENEMY_POOL[5]], rewardType: 'artifact', rewards: { gold: 250 } },
];


export const ARTIFACT_SETS: Record<ArtifactSet, { bonus: string; pieces: number; stat: StatName; value: number }> = {
    AttackSet: { bonus: '+15% Attack', pieces: 2, stat: 'attack', value: 15 },
    HealthSet: { bonus: '+15% HP', pieces: 2, stat: 'maxHp', value: 15 },
    DefenseSet: { bonus: '+15% Defense', pieces: 2, stat: 'defense', value: 15 },
    SpeedSet: { bonus: '+12% Speed', pieces: 4, stat: 'speed', value: 12 },
};

export const ARTIFACT_MAIN_STATS: Record<string, {stat: StatName, isPercent: boolean}[]> = {
    Weapon: [{stat: 'attack', isPercent: false}],
    Helmet: [{stat: 'maxHp', isPercent: false}],
    Armor: [{stat: 'defense', isPercent: false}],
    Boots: [
        {stat: 'speed', isPercent: false},
        {stat: 'attack', isPercent: true},
        {stat: 'defense', isPercent: true},
        {stat: 'maxHp', isPercent: true},
    ],
};