import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Hero, Artifact, ArtifactSlot, GameAction, ButtonProps, HeroCardProps, TavernScreenProps, HeroRosterScreenProps, WorldMapScreenProps, BattleScreenProps, ArtifactsScreenProps, Rarity } from './types';
import { RARITY_STYLES, STAGES, DUNGEONS, getLevelUpCost, ARTIFACT_SETS } from './data';
import { createHeroInstance, getAiAction, calculateFinalHeroStats } from './utils';

// --- GENERIC UI COMPONENTS ---

export const Button: React.FC<ButtonProps> = ({ onClick, children, primary = false, disabled = false, style }) => {
    const baseStyle: React.CSSProperties = {
        padding: '10px 20px', border: `2px solid ${primary ? 'var(--accent-gold)' : 'var(--border-color)'}`,
        borderRadius: '5px', background: primary ? 'var(--accent-gold)' : 'var(--bg-dark-secondary)',
        color: primary ? 'var(--bg-dark-main)' : 'var(--text-light)', fontFamily: 'var(--font-main)',
        fontSize: '1rem', cursor: 'pointer', transition: 'all 0.2s ease', fontWeight: 'bold',
        opacity: disabled ? 0.5 : 1, pointerEvents: disabled ? 'none' : 'auto',
    };
    return <button onClick={onClick} disabled={disabled} style={{ ...baseStyle, ...style }}>{children}</button>;
};

export const HeroCard: React.FC<HeroCardProps> = ({ hero, finalStats, isSelected, onClick, isBattle = false, isTargetable = false, isTurn = false, damageTaken, isAiThinking = false }) => {
    const rarityStyle = RARITY_STYLES[hero.rarity];
    const displayHero = finalStats || hero;
    const cardStyle: React.CSSProperties = {
        width: isBattle ? 120 : 150, height: isBattle ? 180 : 220, border: `3px solid ${rarityStyle.color}`,
        borderRadius: '10px', background: 'var(--bg-dark-secondary)', padding: '10px', textAlign: 'center',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between', alignItems: 'center',
        boxShadow: isSelected ? `0 0 15px ${rarityStyle.color}` : rarityStyle.shadow,
        cursor: onClick && !isBattle ? 'pointer' : 'default', transition: 'transform 0.2s, box-shadow 0.2s',
        transform: isSelected ? 'scale(1.05)' : 'scale(1)', position: 'relative',
        animation: isAiThinking ? 'ai-thinking 1.5s infinite ease-in-out' : (isTurn ? 'pulse 1.5s infinite' : 'none'),
    };
    if (isTargetable) cardStyle.cursor = 'pointer';
    const hpPercentage = (displayHero.hp / displayHero.maxHp) * 100;

    return (
        <div style={cardStyle} onClick={onClick}>
            {damageTaken && <div style={{ position: 'absolute', top: '40%', left: 0, right: 0, margin: 'auto', fontSize: '2rem', fontWeight: 'bold', color: 'var(--accent-red)', animation: 'shake 0.5s', zIndex: 10 }}>-{damageTaken}</div>}
            <div style={{ fontFamily: 'var(--font-main)', fontSize: isBattle ? '0.9rem' : '1.1rem', color: rarityStyle.color }}>{hero.name}</div>
            <div style={{ fontSize: isBattle ? '3rem' : '4rem' }}>{hero.imageUrl}</div>
            {isBattle && (
                <div style={{ width: '90%', background: '#333', borderRadius: '5px', height: '10px', border: '1px solid #555' }}>
                    <div style={{ width: `${hpPercentage}%`, background: hpPercentage > 50 ? 'var(--accent-green)' : hpPercentage > 20 ? 'var(--accent-gold)' : 'var(--accent-red)', height: '100%', borderRadius: '4px' }}></div>
                </div>
            )}
            <div>
                <div style={{ fontSize: isBattle ? '0.7rem' : '0.8rem' }}>Lvl {hero.level} | {hero.role}</div>
                {isBattle && <div style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>{displayHero.hp}/{displayHero.maxHp}</div>}
            </div>
        </div>
    );
};

export const ScreenContainer: React.FC<{ isVisible: boolean, children: React.ReactNode }> = ({ isVisible, children }) => {
    return <div className={`screen-container ${isVisible ? 'visible' : ''}`}>{children}</div>;
};


// --- UI COMPONENTS ---

export const HUD: React.FC<{ playerName: string, crystals: number, gold: number, onMenuClick: () => void }> = ({ playerName, crystals, gold, onMenuClick }) => {
    const hudStyle: React.CSSProperties = {
        position: 'fixed', top: 0, left: 0, width: '100%', height: '50px', background: 'rgba(31, 31, 45, 0.8)',
        backdropFilter: 'blur(5px)', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '0 20px', borderBottom: '2px solid var(--border-color)', zIndex: 100
    };
    return (
        <div style={hudStyle}>
            <div style={{ fontFamily: 'var(--font-main)', fontSize: '1.2rem' }}>{playerName}</div>
            <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                <span style={{ fontSize: '1.2rem' }}>💎 {crystals}</span>
                <span style={{ fontSize: '1.2rem' }}>💰 {gold}</span>
                <button onClick={onMenuClick} style={{ background: 'none', border: 'none', color: 'var(--text-light)', fontSize: '1.5rem', cursor: 'pointer' }}>⚙️</button>
            </div>
        </div>
    );
};

export const DebugPanel: React.FC<{ dispatch: React.Dispatch<GameAction> }> = ({ dispatch }) => {
    const panelStyle: React.CSSProperties = {
        position: 'fixed', top: '60px', right: '10px', background: 'var(--bg-dark-secondary)',
        border: '2px solid var(--border-color)', borderRadius: '5px', padding: '15px',
        display: 'flex', flexDirection: 'column', gap: '10px', zIndex: 200, animation: 'fadeIn 0.3s'
    };
    return (
        <div style={panelStyle}>
            <h3 style={{ fontFamily: 'var(--font-main)' }}>Debug Panel</h3>
            <Button onClick={() => dispatch({ type: 'ADD_CURRENCY', payload: { gold: 1000 } })}>+1000 Gold</Button>
            <Button onClick={() => dispatch({ type: 'ADD_CURRENCY', payload: { crystals: 10 } })}>+10 Crystals</Button>
            <Button onClick={() => dispatch({ type: 'UNLOCK_ALL_STAGES' })}>Unlock All Stages</Button>
            <Button onClick={() => dispatch({ type: 'RESET_GAME' })}>Reset Game</Button>
        </div>
    );
};

// --- SCREEN COMPONENTS ---

export const TavernScreen: React.FC<TavernScreenProps> = ({ dispatch, battleResult }) => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px', animation: 'fadeIn 0.5s' }}>
            <h1 style={{ fontFamily: 'var(--font-main)', fontSize: '3rem' }}>The Crimson Gryphon</h1>
            {battleResult && (
                <div style={{ padding: '10px', background: 'var(--bg-dark-secondary)', borderRadius: '5px' }}>
                    {battleResult.result === 'victory' ? `Victory in ${battleResult.details}!` : `Defeat in ${battleResult.details}.`}
                </div>
            )}
            <div style={{display: 'flex', gap: '15px'}}>
                <Button primary onClick={() => dispatch({ type: 'NAVIGATE', screen: 'ROSTER' })}>Heroes</Button>
                <Button primary onClick={() => dispatch({ type: 'NAVIGATE', screen: 'ARTIFACTS' })}>Artifacts</Button>
            </div>
            <Button onClick={() => dispatch({ type: 'NAVIGATE', screen: 'SUMMON' })}>Summoning Portal</Button>
        </div>
    );
};

const StatDisplay: React.FC<{ label: string, baseValue: number, finalValue: number }> = ({ label, baseValue, finalValue }) => {
    const bonus = finalValue - baseValue;
    return (
        <p>{label}: {baseValue} {bonus > 0 && <span style={{ color: 'var(--accent-green)' }}>(+{bonus})</span>} = {finalValue}</p>
    );
};

const ArtifactSlotDisplay: React.FC<{ slot: ArtifactSlot, artifact: Artifact | null, onClick: () => void }> = ({ slot, artifact, onClick }) => {
    const style: React.CSSProperties = {
        width: 60, height: 60, border: '2px dashed var(--border-color)', borderRadius: '5px', display: 'flex',
        justifyContent: 'center', alignItems: 'center', cursor: 'pointer', background: 'var(--bg-dark-main)'
    };
    if (artifact) {
        style.borderColor = RARITY_STYLES[artifact.rarity].color;
        style.borderStyle = 'solid';
    }
    const iconMap = { Weapon: '⚔️', Helmet: '👑', Armor: '👕', Boots: '👢' };

    return (
        <div onClick={onClick} style={style} title={artifact ? `${artifact.rarity} ${artifact.set} (+${artifact.level})` : `Empty ${slot} Slot`}>
            {artifact ? <span style={{fontSize: '2rem'}}>{iconMap[slot]}</span> : <span style={{fontSize: '2rem'}}>+</span>}
        </div>
    );
}

const ArtifactCard: React.FC<{artifact: Artifact, isEquipped: boolean, onClick?: () => void}> = ({artifact, isEquipped, onClick}) => {
    const rarityStyle = RARITY_STYLES[artifact.rarity];
    return (
        <div onClick={onClick} style={{ border: `2px solid ${rarityStyle.color}`, borderRadius: '5px', padding: '10px', background: 'var(--bg-dark-main)', cursor: onClick ? 'pointer' : 'default', opacity: isEquipped ? 0.5 : 1 }}>
            <p style={{color: rarityStyle.color, fontFamily: 'var(--font-main)'}}>Lvl {artifact.level} {artifact.set}</p>
            <p>{artifact.slot}</p>
            <p><strong>{artifact.mainStat.stat}: {Math.round(artifact.mainStat.value)}{artifact.mainStat.isPercent ? '%' : ''}</strong></p>
        </div>
    )
}

const ArtifactEquipModal: React.FC<{ hero: Hero, slot: ArtifactSlot, allArtifacts: Artifact[], equippedArtifactsUuids: string[], dispatch: React.Dispatch<GameAction>, onClose: () => void }> =
({ hero, slot, allArtifacts, equippedArtifactsUuids, dispatch, onClose }) => {
    const availableArtifacts = allArtifacts.filter(a => a.slot === slot && !equippedArtifactsUuids.includes(a.uuid));
    const currentArtifactUuid = hero.equippedArtifacts[slot];
    
    return (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ background: 'var(--bg-dark-secondary)', padding: '20px', borderRadius: '10px', width: '80%', maxWidth: '800px', maxHeight: '80vh', display: 'flex', flexDirection: 'column' }}>
                <h2 style={{fontFamily: 'var(--font-main)'}}>Equip {slot} for {hero.name}</h2>
                {currentArtifactUuid && <Button style={{marginBottom: '10px'}} onClick={() => { dispatch({type: 'UNEQUIP_ARTIFACT', payload: {heroUuid: hero.uuid, slot}}); onClose(); }}>Unequip Current</Button>}
                <div style={{ overflowY: 'auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '10px' }}>
                    {availableArtifacts.length > 0 ? availableArtifacts.map(art => (
                        <ArtifactCard key={art.uuid} artifact={art} isEquipped={false} onClick={() => { dispatch({type: 'EQUIP_ARTIFACT', payload: {heroUuid: hero.uuid, artifactUuid: art.uuid}}); onClose(); }} />
                    )) : <p>No available artifacts for this slot.</p>}
                </div>
                <Button onClick={onClose} style={{ marginTop: '20px', alignSelf: 'flex-end' }}>Close</Button>
            </div>
        </div>
    )
}

export const HeroRosterScreen: React.FC<HeroRosterScreenProps> = ({ heroes, allArtifacts, team, dispatch, gold }) => {
    const [selectedTeam, setSelectedTeam] = useState<string[]>(team);
    const [selectedHeroUuid, setSelectedHeroUuid] = useState<string | null>(heroes.length > 0 ? heroes[0].uuid : null);
    const [modalSlot, setModalSlot] = useState<ArtifactSlot | null>(null);

    const selectedHero = useMemo(() => heroes.find(h => h.uuid === selectedHeroUuid), [heroes, selectedHeroUuid]);
    const finalHeroStats = useMemo(() => selectedHero ? calculateFinalHeroStats(selectedHero, allArtifacts) : null, [selectedHero, allArtifacts]);
    
    const equippedArtifactsUuids = useMemo(() => {
        return heroes.flatMap(h => Object.values(h.equippedArtifacts)).filter(Boolean) as string[];
    }, [heroes]);

    const handleSelectHero = (uuid: string) => {
        if (selectedTeam.includes(uuid)) {
            setSelectedTeam(selectedTeam.filter(id => id !== uuid));
        } else if (selectedTeam.length < 3) {
            setSelectedTeam([...selectedTeam, uuid]);
        }
    };
    
    const levelUpCost = selectedHero ? getLevelUpCost(selectedHero.level) : 0;

    return (
        <div style={{ display: 'flex', width: '90%', height: '85vh', gap: '20px', animation: 'fadeIn 0.5s' }}>
            {modalSlot && selectedHero && <ArtifactEquipModal hero={selectedHero} slot={modalSlot} allArtifacts={allArtifacts} equippedArtifactsUuids={equippedArtifactsUuids} dispatch={dispatch} onClose={() => setModalSlot(null)} />}
            
            {/* Left Panel: Hero Details */}
            <div style={{ flex: 1, background: 'var(--bg-dark-secondary)', borderRadius: '10px', padding: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px' }}>
                {selectedHero && finalHeroStats ? (
                    <>
                        <h2 style={{ fontFamily: 'var(--font-main)' }}>{selectedHero.name}</h2>
                        <HeroCard hero={selectedHero} finalStats={finalHeroStats} />
                        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px'}}>
                            {(Object.keys(selectedHero.equippedArtifacts) as ArtifactSlot[]).map(slot => (
                                <ArtifactSlotDisplay key={slot} slot={slot} artifact={allArtifacts.find(a => a.uuid === selectedHero.equippedArtifacts[slot]) || null} onClick={() => setModalSlot(slot)} />
                            ))}
                        </div>
                        <StatDisplay label="HP" baseValue={selectedHero.maxHp} finalValue={finalHeroStats.maxHp} />
                        <StatDisplay label="ATK" baseValue={selectedHero.attack} finalValue={finalHeroStats.attack} />
                        <StatDisplay label="DEF" baseValue={selectedHero.defense} finalValue={finalHeroStats.defense} />
                        <StatDisplay label="SPD" baseValue={selectedHero.speed} finalValue={finalHeroStats.speed} />
                        <Button onClick={() => dispatch({ type: 'LEVEL_UP_HERO', heroUuid: selectedHero.uuid! })} disabled={gold < levelUpCost}>
                            Level Up (Cost: {levelUpCost} 💰)
                        </Button>
                    </>
                ) : <p>Select a hero to view details.</p>}
            </div>

            {/* Right Panel: Roster & Team */}
            <div style={{ flex: 2, display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div style={{ flex: 3, background: 'var(--bg-dark-secondary)', borderRadius: '10px', padding: '20px', overflowY: 'auto' }}>
                    <h3 style={{ fontFamily: 'var(--font-main)', marginBottom: '15px' }}>Your Heroes</h3>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px' }}>
                        {heroes.map(hero => (
                            <div key={hero.uuid} onClick={() => setSelectedHeroUuid(hero.uuid)}>
                                <HeroCard hero={hero} isSelected={selectedTeam.includes(hero.uuid)} onClick={() => handleSelectHero(hero.uuid)} />
                            </div>
                        ))}
                    </div>
                </div>
                <div style={{ flex: 1, background: 'var(--bg-dark-secondary)', borderRadius: '10px', padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '15px' }}>
                    <h3 style={{ fontFamily: 'var(--font-main)' }}>Your Team ({selectedTeam.length}/3)</h3>
                    <div style={{ display: 'flex', gap: '10px' }}>
                        {heroes.filter(h => selectedTeam.includes(h.uuid)).map(h => <HeroCard key={h.uuid} hero={h} finalStats={calculateFinalHeroStats(h, allArtifacts)} isBattle />)}
                    </div>
                    <div style={{ display: 'flex', gap: '20px', marginTop: '10px' }}>
                        <Button onClick={() => dispatch({ type: 'NAVIGATE', screen: 'TAVERN' })}>Back to Tavern</Button>
                        <Button primary disabled={selectedTeam.length !== 3} onClick={() => { dispatch({ type: 'SET_TEAM', team: selectedTeam }); dispatch({ type: 'NAVIGATE', screen: 'WORLD_MAP' }); }}>
                            Proceed to Battle
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const WorldMapScreen: React.FC<WorldMapScreenProps> = ({ unlockedStage, dispatch }) => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '30px', animation: 'fadeIn 0.5s' }}>
            <h1 style={{ fontFamily: 'var(--font-main)', fontSize: '3rem' }}>World Map</h1>
            <div style={{display: 'flex', gap: '50px'}}>
                <div style={{display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'center'}}>
                    <h2 style={{fontFamily: 'var(--font-main)'}}>Campaign</h2>
                    {STAGES.map(stage => (
                        <Button key={stage.id} disabled={stage.id > unlockedStage} onClick={() => dispatch({ type: 'START_BATTLE', stageId: stage.id })}>
                            Stage {stage.id}: {stage.name}
                        </Button>
                    ))}
                </div>
                <div style={{display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'center'}}>
                     <h2 style={{fontFamily: 'var(--font-main)'}}>Dungeons</h2>
                     {DUNGEONS.map(dungeon => (
                         <Button key={dungeon.id} onClick={() => dispatch({ type: 'START_DUNGEON', dungeonId: dungeon.id })}>
                             {dungeon.name}
                         </Button>
                     ))}
                </div>
            </div>
            <Button onClick={() => dispatch({ type: 'NAVIGATE', screen: 'ROSTER' })}>Back to Team</Button>
        </div>
    );
};

export const ArtifactsScreen: React.FC<ArtifactsScreenProps> = ({ artifacts, heroes, gold, dispatch }) => {
    const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);

    const equippedBy = (artifactUuid: string): string | null => {
        const hero = heroes.find(h => Object.values(h.equippedArtifacts).includes(artifactUuid));
        return hero ? hero.name : null;
    }

    const upgradeCost = selectedArtifact ? (selectedArtifact.level + 1) * 100 : 0;

    return (
        <div style={{ display: 'flex', width: '90%', height: '85vh', gap: '20px', animation: 'fadeIn 0.5s' }}>
            <div style={{ flex: 2, background: 'var(--bg-dark-secondary)', borderRadius: '10px', padding: '20px', overflowY: 'auto' }}>
                <h3 style={{ fontFamily: 'var(--font-main)', marginBottom: '15px' }}>Your Artifacts ({artifacts.length})</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '10px' }}>
                    {artifacts.map(art => (
                        <div key={art.uuid} onClick={() => setSelectedArtifact(art)}>
                            <ArtifactCard artifact={art} isEquipped={!!equippedBy(art.uuid)} />
                        </div>
                    ))}
                </div>
            </div>
            <div style={{ flex: 1, background: 'var(--bg-dark-secondary)', borderRadius: '10px', padding: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px' }}>
                <h2 style={{ fontFamily: 'var(--font-main)' }}>Artifact Details</h2>
                {selectedArtifact ? (
                    <>
                        <ArtifactCard artifact={selectedArtifact} isEquipped={!!equippedBy(selectedArtifact.uuid)} />
                        {equippedBy(selectedArtifact.uuid) && <p>Equipped by: {equippedBy(selectedArtifact.uuid)}</p>}
                        <Button onClick={() => dispatch({ type: 'UPGRADE_ARTIFACT', artifactUuid: selectedArtifact.uuid })} disabled={gold < upgradeCost}>Upgrade (Cost: {upgradeCost} 💰)</Button>
                    </>
                ) : <p>Select an artifact.</p>}
                 <Button onClick={() => dispatch({ type: 'NAVIGATE', screen: 'TAVERN' })} style={{marginTop: 'auto'}}>Back to Tavern</Button>
            </div>
        </div>
    );
};

export const BattleScreen: React.FC<BattleScreenProps> = ({ playerHeroes, allArtifacts, playerTeamUuids, stageId, dungeonId, dispatch }) => {
    const battleInfo = useMemo(() => {
        if (dungeonId) return DUNGEONS.find(d => d.id === dungeonId)!;
        return STAGES.find(s => s.id === stageId)!;
    }, [stageId, dungeonId]);

    const initialPlayerTeam = useMemo(() => playerHeroes
        .filter(h => playerTeamUuids.includes(h.uuid))
        .map(h => ({ ...calculateFinalHeroStats(h, allArtifacts), hp: calculateFinalHeroStats(h, allArtifacts).maxHp })), 
        [playerHeroes, playerTeamUuids, allArtifacts]);

    const initialEnemyTeam = useMemo(() => battleInfo.enemies
        .map(template => createHeroInstance(template, true))
        .map(e => ({ ...calculateFinalHeroStats(e, []), hp: calculateFinalHeroStats(e, []).maxHp })),
        [battleInfo.enemies]);
    
    const [playerTeam, setPlayerTeam] = useState<Hero[]>(initialPlayerTeam);
    const [enemyTeam, setEnemyTeam] = useState<Hero[]>(initialEnemyTeam);
    const [turnQueue, setTurnQueue] = useState<(Hero & { team: 'player' | 'enemy' })[]>([]);
    const [currentTurnIndex, setCurrentTurnIndex] = useState(0);
    const [log, setLog] = useState<string[]>(['Battle Start!']);
    const [damageDisplay, setDamageDisplay] = useState<Record<string, number | null>>({});
    const [isPlayerTurn, setIsPlayerTurn] = useState(false);
    const [isAiThinking, setIsAiThinking] = useState<string | null>(null);
    
    const addToLog = useCallback((message: string) => setLog(prev => [message, ...prev.slice(0, 4)]), []);

    useEffect(() => {
        const allUnits = [
            ...playerTeam.map(h => ({ ...h, team: 'player' as const })),
            ...enemyTeam.map(e => ({ ...e, team: 'enemy' as const }))
        ].sort((a, b) => b.speed - a.speed);
        setTurnQueue(allUnits);
        addToLog(`Entering ${battleInfo.name}`);
    }, []);

    const currentTurnUnit = turnQueue[currentTurnIndex];

    const nextTurn = useCallback(() => {
        setIsPlayerTurn(false);
        setIsAiThinking(null);
        setDamageDisplay({});
        const nextIndex = (currentTurnIndex + 1) % turnQueue.length;
        
        let tempIndex = nextIndex;
        let stopCondition = 0;
        while (turnQueue[tempIndex].hp <= 0 && stopCondition < turnQueue.length) {
            tempIndex = (tempIndex + 1) % turnQueue.length;
            stopCondition++;
        }
        setCurrentTurnIndex(tempIndex);
    }, [currentTurnIndex, turnQueue]);

    useEffect(() => {
        if (turnQueue.length === 0) return;
        
        const alivePlayerTeam = playerTeam.filter(h => h.hp > 0);
        const aliveEnemyTeam = enemyTeam.filter(h => h.hp > 0);

        if (alivePlayerTeam.length === 0) {
            addToLog('All heroes have been defeated!');
            setTimeout(() => dispatch({ type: 'END_BATTLE', result: 'defeat', rewards: { crystals: 0, gold: 0 } }), 2000);
            return;
        }
        if (aliveEnemyTeam.length === 0) {
            addToLog('Victory!');
            const finalRewards = {
                gold: battleInfo.rewards.gold,
                crystals: 'crystals' in battleInfo.rewards ? battleInfo.rewards.crystals : 0,
            };
            setTimeout(() => dispatch({ type: 'END_BATTLE', result: 'victory', rewards: finalRewards }), 2000);
            return;
        }

        const unit = turnQueue[currentTurnIndex];
        if (!unit || unit.hp <= 0) {
            nextTurn();
            return;
        }
        
        addToLog(`${unit.name}'s turn.`);
        if (unit.team === 'player') {
            setIsPlayerTurn(true);
        } else {
            setIsPlayerTurn(false);
            setIsAiThinking(unit.uuid);
            setTimeout(async () => {
                const action = await getAiAction(unit, alivePlayerTeam, aliveEnemyTeam);
                if (action && action.target) {
                    handleAttack(unit, action.target);
                } else {
                    addToLog(`${unit.name} is unable to act.`);
                    setTimeout(nextTurn, 1000);
                }
            }, 1500);
        }
    }, [currentTurnIndex, turnQueue]);

    const handleAttack = (attacker: Hero, targetUuid: string) => {
        const isPlayerAttacker = playerTeam.some(h => h.uuid === attacker.uuid);
        const targetTeam = isPlayerAttacker ? enemyTeam : playerTeam;
        const setTargetTeam = isPlayerAttacker ? setEnemyTeam : setPlayerTeam;
        
        const defender = targetTeam.find(u => u.uuid === targetUuid);
        if (!defender || !attacker) return;

        const damage = Math.max(1, Math.floor(attacker.attack * (1 - defender.defense / (defender.defense + 200)) * (0.8 + Math.random() * 0.4) ));
        const newHp = Math.max(0, defender.hp - damage);
        
        setDamageDisplay(prev => ({...prev, [targetUuid]: damage}));
        addToLog(`${attacker.name} attacks ${defender.name} for ${damage} damage!`);

        setTargetTeam(team => team.map(u => u.uuid === targetUuid ? { ...u, hp: newHp } : u));
        setTurnQueue(queue => queue.map(u => u.uuid === targetUuid ? { ...u, hp: newHp } : u)); // Update queue to reflect new HP for turn skipping
        
        setTimeout(nextTurn, 1000);
    };

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', animation: 'fadeIn 0.5s' }}>
            <div style={{ display: 'flex', gap: '20px', marginBottom: '40px' }}>
                {enemyTeam.map(hero => (
                    <HeroCard key={hero.uuid} hero={hero} isBattle isTargetable={isPlayerTurn} isTurn={currentTurnUnit?.uuid === hero.uuid} damageTaken={damageDisplay[hero.uuid]} isAiThinking={isAiThinking === hero.uuid}
                        onClick={() => { if (isPlayerTurn && currentTurnUnit) handleAttack(currentTurnUnit, hero.uuid); }}
                    />
                ))}
            </div>
            <div style={{ display: 'flex', gap: '20px', marginTop: '40px' }}>
                {playerTeam.map(hero => (
                    <HeroCard key={hero.uuid} hero={hero} isBattle isTurn={currentTurnUnit?.uuid === hero.uuid} damageTaken={damageDisplay[hero.uuid]}/>
                ))}
            </div>
            <div style={{ position: 'absolute', bottom: '20px', left: '20px', width: '300px', height: '120px', background: 'rgba(0,0,0,0.5)', padding: '10px', borderRadius: '5px', overflow: 'hidden' }}>
                {log.map((entry, i) => <p key={i} style={{ margin: 0, fontSize: '0.9rem', opacity: 1 - i * 0.2 }}>{entry}</p>)}
            </div>
        </div>
    );
};