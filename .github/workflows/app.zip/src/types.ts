import React, { CSSProperties, ReactNode } from 'react';

export type Rarity = 'Common' | 'Rare' | 'Epic' | 'Legendary';
export type Role = 'Attacker' | 'Defender' | 'Support' | 'Specialist';

// --- ARTIFACT SYSTEM ---
export type ArtifactSlot = 'Weapon' | 'Helmet' | 'Armor' | 'Boots';
export type ArtifactSet = 'AttackSet' | 'HealthSet' | 'DefenseSet' | 'SpeedSet';
export type StatName = 'maxHp' | 'attack' | 'defense' | 'speed';
export type Stat = {
    stat: StatName;
    value: number;
    isPercent: boolean;
};

export interface Artifact {
    uuid: string;
    set: ArtifactSet;
    slot: ArtifactSlot;
    rarity: Rarity;
    level: number;
    mainStat: Stat;
    subStats: Stat[];
}

export interface Hero {
  id: number;
  name: string;
  rarity: Rarity;
  role: Role;
  level: number;
  maxHp: number; // Base maxHp
  hp: number; // Current health
  attack: number; // Base attack
  defense: number; // Base defense
  speed: number; // Base speed
  imageUrl: string;
  uuid: string; // Unique instance ID
  equippedArtifacts: Record<ArtifactSlot, string | null>;
}

export interface Stage {
    id: number;
    name: string;
    enemies: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'>[];
    rewards: {
        gold: number;
        crystals: number;
    };
}

export interface Dungeon {
    id: number;
    name: string;
    enemies: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'>[];
    rewardType: 'artifact';
    rewards: { gold: number };
}

export interface GameState {
  playerName: string;
  currentScreen: 'TAVERN' | 'SUMMON' | 'ROSTER' | 'WORLD_MAP' | 'BATTLE' | 'ARTIFACTS';
  crystals: number;
  gold: number;
  playerHeroes: Hero[];
  playerTeam: string[]; // array of hero uuids
  currentStage: number;
  currentDungeonId: number | null;
  unlockedStage: number;
  lastSummonedHero: Hero | null;
  battleResult: { result: 'victory' | 'defeat'; details: string } | null;
  isDebugPanelOpen: boolean;
  artifacts: Artifact[];
}

export type GameAction =
  | { type: 'NAVIGATE'; screen: GameState['currentScreen'] }
  | { type: 'SUMMON_HERO'; heroTemplate: Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'> }
  | { type: 'SET_TEAM'; team: string[] }
  | { type: 'START_BATTLE'; stageId: number }
  | { type: 'START_DUNGEON'; dungeonId: number }
  | { type: 'END_BATTLE'; result: 'victory' | 'defeat'; rewards: { crystals: number; gold: number } }
  | { type: 'LEVEL_UP_HERO'; heroUuid: string }
  | { type: 'ADD_ARTIFACT'; artifact: Artifact }
  | { type: 'EQUIP_ARTIFACT'; payload: { heroUuid: string; artifactUuid: string } }
  | { type: 'UNEQUIP_ARTIFACT'; payload: { heroUuid: string; slot: ArtifactSlot } }
  | { type: 'UPGRADE_ARTIFACT'; artifactUuid: string }
  | { type: 'RESET_GAME' }
  | { type: 'TOGGLE_DEBUG_PANEL' }
  | { type: 'ADD_CURRENCY'; payload: { gold?: number; crystals?: number } }
  | { type: 'UNLOCK_ALL_STAGES' };

// Component Prop Types
export interface ButtonProps {
    onClick: (e?: React.MouseEvent<HTMLButtonElement>) => void;
    children?: ReactNode;
    primary?: boolean;
    disabled?: boolean;
    style?: CSSProperties;
}

export interface HeroCardProps {
    hero: Hero;
    finalStats?: Hero;
    isSelected?: boolean;
    onClick?: (e?: React.MouseEvent<HTMLDivElement>) => void;
    isBattle?: boolean;
    isTargetable?: boolean;
    isTurn?: boolean;
    damageTaken?: number | null;
    isAiThinking?: boolean;
}

export interface TavernScreenProps {
    dispatch: React.Dispatch<GameAction>;
    battleResult: GameState['battleResult'];
}

export interface SummonPortalScreenProps {
    crystals: number;
    dispatch: React.Dispatch<GameAction>;
    lastSummonedHero: Hero | null;
}

export interface HeroRosterScreenProps {
    heroes: Hero[];
    allArtifacts: Artifact[];
    team: string[];
    dispatch: React.Dispatch<GameAction>;
    gold: number;
}

export interface WorldMapScreenProps {
    unlockedStage: number;
    dispatch: React.Dispatch<GameAction>;
}

export interface BattleScreenProps {
    playerHeroes: Hero[];
    allArtifacts: Artifact[];
    playerTeamUuids: string[];
    stageId: number;
    dungeonId: number | null;
    dispatch: React.Dispatch<GameAction>;
}

export interface ArtifactsScreenProps {
    artifacts: Artifact[];
    heroes: Hero[];
    gold: number;
    dispatch: React.Dispatch<GameAction>;
}