import React, { useState, useEffect } from 'react';
import { Hero, GameAction, SummonPortalScreenProps, Rarity } from './types';
import { HERO_POOL, SUMMON_CHANCES, RARITY_STYLES } from './data';
import { Button, HeroCard } from './components';

const performSummon = (): Omit<Hero, 'id' | 'uuid' | 'hp' | 'equippedArtifacts'> => {
    const rand = Math.random();
    let cumulative = 0;

    for (const rarity in SUMMON_CHANCES) {
        cumulative += SUMMON_CHANCES[rarity as Rarity];
        if (rand < cumulative) {
            const possibleHeroes = HERO_POOL.filter(h => h.rarity === rarity);
            return possibleHeroes[Math.floor(Math.random() * possibleHeroes.length)];
        }
    }
    // Fallback to common
    const commonHeroes = HERO_POOL.filter(h => h.rarity === 'Common');
    return commonHeroes[Math.floor(Math.random() * commonHeroes.length)];
};

export const SummonPortalScreen: React.FC<SummonPortalScreenProps> = ({ crystals, dispatch, lastSummonedHero }) => {
    const [isSummoning, setIsSummoning] = useState(false);
    
    const handleSummon = () => {
        if (crystals > 0 && !isSummoning) {
            setIsSummoning(true);
            setTimeout(() => {
                const heroTemplate = performSummon();
                dispatch({ type: 'SUMMON_HERO', heroTemplate });
                setIsSummoning(false);
            }, 2000); // 2 second animation
        }
    };

    const portalStyle: React.CSSProperties = {
        width: '250px', height: '400px', border: '5px solid var(--accent-purple)', borderRadius: '125px',
        display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '10rem',
        cursor: 'pointer', transition: 'all 0.3s',
        animation: isSummoning ? 'pulse 2s ease-in-out infinite' : 'none',
        boxShadow: isSummoning ? '0 0 50px var(--accent-purple)' : '0 0 20px var(--accent-purple)',
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '30px', animation: 'fadeIn 0.5s' }}>
            <h1 style={{ fontFamily: 'var(--font-main)', fontSize: '3rem' }}>Summoning Portal</h1>
            <div style={{ display: 'flex', gap: '50px', alignItems: 'center' }}>
                <div onClick={handleSummon} style={portalStyle}>💎</div>
                {lastSummonedHero && (
                    <div style={{ animation: 'fadeIn 0.5s' }}>
                        <h3 style={{fontFamily: 'var(--font-main)', textAlign: 'center', marginBottom: '10px'}}>You Summoned:</h3>
                        <HeroCard hero={lastSummonedHero} />
                    </div>
                )}
            </div>
            <p>Crystals Remaining: {crystals}</p>
            <div style={{display: 'flex', gap: '20px'}}>
                <Button onClick={() => dispatch({ type: 'NAVIGATE', screen: 'TAVERN' })}>Back to Tavern</Button>
                <Button primary onClick={handleSummon} disabled={crystals <= 0 || isSummoning}>
                    {isSummoning ? 'Summoning...' : 'Summon (1 💎)'}
                </Button>
            </div>
        </div>
    );
};