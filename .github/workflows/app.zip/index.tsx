import React, { useState, useReducer, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { GameState, GameAction, Hero } from './src/types';
import { HERO_POOL, STAGES, DUNGEONS, getLevelUpCost, LEVEL_UP_STAT_INCREASE_PERCENT } from './src/data';
import { HUD, DebugPanel, ScreenContainer, TavernScreen, HeroRosterScreen, WorldMapScreen, BattleScreen, ArtifactsScreen } from './src/components';
import { SummonPortalScreen } from './src/summon';
import { createHeroInstance, createArtifactInstance } from './src/utils';

// --- STYLE INJECTION ---
const styleElement = document.createElement('style');
styleElement.innerHTML = `
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Roboto:wght@300;400;700&display=swap');
  :root {
    --bg-dark-main: #12121c; --bg-dark-secondary: #1f1f2d; --border-color: #3a3a50;
    --text-light: #e0e0e0; --text-dark: #a0a0b0; --accent-gold: #f7b538;
    --accent-purple: #8a4fff; --accent-red: #e63946; --accent-green: #52b788;
    --font-main: 'Cinzel', serif; --font-body: 'Roboto', sans-serif;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: var(--font-body); background-color: var(--bg-dark-main); color: var(--text-light); overflow: hidden; }
  #root { width: 100%; height: 100vh; display: flex; justify-content: center; align-items: center; }
  .screen-container { position: absolute; width: 100%; height: 100%; display: flex; justify-content: center; align-items: center; transition: opacity 0.3s ease-in-out; opacity: 0; pointer-events: none; }
  .screen-container.visible { opacity: 1; pointer-events: auto; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes pulse { 0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(247, 181, 56, 0.4); } 70% { transform: scale(1.05); box-shadow: 0 0 10px 15px rgba(247, 181, 56, 0); } 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(247, 181, 56, 0); } }
  @keyframes ai-thinking { 0% { box-shadow: 0 0 15px var(--accent-purple); } 50% { box-shadow: 0 0 25px var(--accent-purple), 0 0 10px white; } 100% { box-shadow: 0 0 15px var(--accent-purple); } }
  @keyframes shake { 0%, 100% { transform: translateX(0); } 20%, 60% { transform: translateX(-5px); } 40%, 80% { transform: translateX(5px); } }
`;
document.head.appendChild(styleElement);

// --- GAME STATE & REDUCER ---
const initialHeroes = [createHeroInstance(HERO_POOL[0]), createHeroInstance(HERO_POOL[1])];

const initialState: GameState = {
  playerName: 'The Guardian',
  currentScreen: 'TAVERN',
  crystals: 5,
  gold: 1000,
  playerHeroes: initialHeroes,
  playerTeam: [],
  currentStage: 0,
  currentDungeonId: null,
  unlockedStage: 1,
  lastSummonedHero: null,
  battleResult: null,
  isDebugPanelOpen: false,
  artifacts: [],
};

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'NAVIGATE':
      return { ...state, currentScreen: action.screen, battleResult: null, lastSummonedHero: null };
    case 'SUMMON_HERO':
        if (state.crystals <= 0) return state;
        const newHero = createHeroInstance(action.heroTemplate);
        return { ...state, crystals: state.crystals - 1, playerHeroes: [...state.playerHeroes, newHero], lastSummonedHero: newHero };
    case 'SET_TEAM':
        return { ...state, playerTeam: action.team };
    case 'START_BATTLE':
        return { ...state, currentScreen: 'BATTLE', currentStage: action.stageId, currentDungeonId: null, battleResult: null };
    case 'START_DUNGEON':
        return { ...state, currentScreen: 'BATTLE', currentDungeonId: action.dungeonId, currentStage: 0, battleResult: null };
    case 'END_BATTLE': {
        const isVictory = action.result === 'victory';
        if (!isVictory) {
            return {...state, battleResult: { result: 'defeat', details: state.currentDungeonId ? `Dungeon ${state.currentDungeonId}` : `Stage ${state.currentStage}` }, currentScreen: 'TAVERN' };
        }

        let newUnlockedStage = state.unlockedStage;
        let newCrystals = state.crystals;
        let newGold = state.gold + (isVictory ? action.rewards.gold : 0);
        let newArtifacts = state.artifacts;

        if (state.currentDungeonId !== null) {
            // Dungeon victory
            const dungeon = DUNGEONS.find(d => d.id === state.currentDungeonId);
            if (dungeon?.rewardType === 'artifact') {
                const slots: any[] = ['Weapon', 'Helmet', 'Armor', 'Boots'];
                const rarities: any[] = ['Common', 'Rare'];
                const newArtifact = createArtifactInstance(rarities[Math.floor(Math.random() * rarities.length)], 1, slots[Math.floor(Math.random() * slots.length)]);
                newArtifacts = [...state.artifacts, newArtifact];
            }
        } else {
            // Campaign victory
            newUnlockedStage = isVictory && state.currentStage === state.unlockedStage && state.unlockedStage < STAGES.length ? state.unlockedStage + 1 : state.unlockedStage;
            newCrystals += (isVictory ? action.rewards.crystals : 0);
        }

        return {
            ...state,
            battleResult: { result: 'victory', details: state.currentDungeonId ? `Dungeon ${state.currentDungeonId}` : `Stage ${state.currentStage}`},
            currentScreen: 'TAVERN',
            unlockedStage: newUnlockedStage,
            crystals: newCrystals,
            gold: newGold,
            artifacts: newArtifacts,
        };
    }
    case 'LEVEL_UP_HERO': {
        const hero = state.playerHeroes.find(h => h.uuid === action.heroUuid);
        if (!hero) return state;
        const cost = getLevelUpCost(hero.level);
        if (state.gold < cost) return state;
        const leveledUpHero = { ...hero, level: hero.level + 1, maxHp: Math.floor(hero.maxHp * LEVEL_UP_STAT_INCREASE_PERCENT), attack: Math.floor(hero.attack * LEVEL_UP_STAT_INCREASE_PERCENT), defense: Math.floor(hero.defense * LEVEL_UP_STAT_INCREASE_PERCENT) };
        leveledUpHero.hp = leveledUpHero.maxHp;
        return { ...state, gold: state.gold - cost, playerHeroes: state.playerHeroes.map(h => h.uuid === action.heroUuid ? leveledUpHero : h) };
    }
    case 'ADD_ARTIFACT':
        return { ...state, artifacts: [...state.artifacts, action.artifact] };
    case 'EQUIP_ARTIFACT': {
        const { heroUuid, artifactUuid } = action.payload;
        const artifactToEquip = state.artifacts.find(a => a.uuid === artifactUuid);
        if (!artifactToEquip) return state;

        // Create a mutable copy of heroes to track un-equipping
        const heroesCopy = JSON.parse(JSON.stringify(state.playerHeroes));
        
        // Find if any other hero has this artifact equipped and un-equip it
        const currentHolder = heroesCopy.find((h: Hero) => Object.values(h.equippedArtifacts).includes(artifactUuid));
        if (currentHolder) {
            const slot = (Object.keys(currentHolder.equippedArtifacts) as (keyof Hero['equippedArtifacts'])[]).find(s => currentHolder.equippedArtifacts[s] === artifactUuid);
            if (slot) currentHolder.equippedArtifacts[slot] = null;
        }

        // Find the target hero and equip the artifact
        const targetHero = heroesCopy.find((h: Hero) => h.uuid === heroUuid);
        if (targetHero) {
            // Check if there's an artifact in the target slot and un-equip it (implicitly, as it's not re-assigned)
            targetHero.equippedArtifacts[artifactToEquip.slot] = artifactToEquip.uuid;
        }
        
        return { ...state, playerHeroes: heroesCopy };
    }
    case 'UNEQUIP_ARTIFACT': {
        const { heroUuid, slot } = action.payload;
        return {
            ...state,
            playerHeroes: state.playerHeroes.map(h => h.uuid === heroUuid ? { ...h, equippedArtifacts: { ...h.equippedArtifacts, [slot]: null } } : h)
        };
    }
     case 'UPGRADE_ARTIFACT': {
        const artifact = state.artifacts.find(a => a.uuid === action.artifactUuid);
        if (!artifact) return state;
        const cost = (artifact.level + 1) * 100; // simple cost
        if (state.gold < cost) return state;
        
        const upgradedArtifact = { ...artifact, level: artifact.level + 1, mainStat: { ...artifact.mainStat, value: artifact.mainStat.value * 1.15 } };
        
        return { ...state, gold: state.gold - cost, artifacts: state.artifacts.map(a => a.uuid === action.artifactUuid ? upgradedArtifact : a) };
    }
    case 'TOGGLE_DEBUG_PANEL':
        return { ...state, isDebugPanelOpen: !state.isDebugPanelOpen };
    case 'ADD_CURRENCY':
        return { ...state, gold: state.gold + (action.payload.gold || 0), crystals: state.crystals + (action.payload.crystals || 0) };
    case 'UNLOCK_ALL_STAGES':
        return { ...state, unlockedStage: STAGES.length };
    case 'RESET_GAME':
        const newInitialHeroes = [createHeroInstance(HERO_POOL[0]), createHeroInstance(HERO_POOL[1])];
        return { ...initialState, playerHeroes: newInitialHeroes, playerTeam: [], isDebugPanelOpen: state.isDebugPanelOpen };
    default:
      return state;
  }
}

// --- MAIN APP COMPONENT ---
const App = () => {
  const [state, dispatch] = useReducer(gameReducer, initialState);
  const [activeScreen, setActiveScreen] = useState(state.currentScreen);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (state.currentScreen !== activeScreen) {
      setIsExiting(true);
      const timer = setTimeout(() => {
        setActiveScreen(state.currentScreen);
        setIsExiting(false);
      }, 300); // Match CSS transition time
      return () => clearTimeout(timer);
    }
  }, [state.currentScreen, activeScreen]);

  useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
          if (e.code === 'Backquote') { // ~ key
              dispatch({ type: 'TOGGLE_DEBUG_PANEL' });
          }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

   const API_KEY = process.env.API_KEY;

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <HUD
        playerName={state.playerName}
        crystals={state.crystals}
        gold={state.gold}
        onMenuClick={() => dispatch({ type: 'TOGGLE_DEBUG_PANEL' })}
      />
      <ScreenContainer isVisible={activeScreen === 'TAVERN' && !isExiting}>
        <TavernScreen dispatch={dispatch} battleResult={state.battleResult} />
      </ScreenContainer>
      <ScreenContainer isVisible={activeScreen === 'SUMMON' && !isExiting}>
        <SummonPortalScreen crystals={state.crystals} dispatch={dispatch} lastSummonedHero={state.lastSummonedHero} />
      </ScreenContainer>
      <ScreenContainer isVisible={activeScreen === 'ROSTER' && !isExiting}>
        <HeroRosterScreen heroes={state.playerHeroes} allArtifacts={state.artifacts} team={state.playerTeam} dispatch={dispatch} gold={state.gold} />
      </ScreenContainer>
      <ScreenContainer isVisible={activeScreen === 'WORLD_MAP' && !isExiting}>
        <WorldMapScreen unlockedStage={state.unlockedStage} dispatch={dispatch} />
      </ScreenContainer>
       <ScreenContainer isVisible={activeScreen === 'BATTLE' && !isExiting}>
        <BattleScreen playerHeroes={state.playerHeroes} allArtifacts={state.artifacts} playerTeamUuids={state.playerTeam} stageId={state.currentStage} dungeonId={state.currentDungeonId} dispatch={dispatch} />
      </ScreenContainer>
      <ScreenContainer isVisible={activeScreen === 'ARTIFACTS' && !isExiting}>
          <ArtifactsScreen artifacts={state.artifacts} heroes={state.playerHeroes} gold={state.gold} dispatch={dispatch} />
      </ScreenContainer>
      
      {state.isDebugPanelOpen && <DebugPanel dispatch={dispatch} />}
      {!API_KEY && <div style={{ position: 'fixed', bottom: 10, left: 10, background: 'var(--accent-red)', padding: '10px', borderRadius: '5px' }}>API_KEY not found. AI will use fallback logic.</div>}
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
    const root = createRoot(container);
    root.render(<App />);
}
